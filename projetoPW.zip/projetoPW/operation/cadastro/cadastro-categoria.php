<?php
    require_once("../../router.php");

    if(CategoriaController::verificaPreenchimento()){
        if(!CategoriaDAO::verificaCategoria($_POST['nomeCategoria'])){
            CategoriaDAO::cadastrarCategoria($_POST['nomeCategoria']);
        }
    }

    header("Location: ../../view/dashboard/pages/forms/cadastro-categoria.php");
?>