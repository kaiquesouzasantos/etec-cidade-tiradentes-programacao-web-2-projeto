<?php
    require_once("../../router.php");

    if(isset($_GET['codVenda']) or isset($_GET['codProduto'])){
        ItemVendaDAO::removeItem($_GET['codVenda'], $_GET['codProduto']);
    }

    header("Location: ../../view/carrinho/index.php");

?>