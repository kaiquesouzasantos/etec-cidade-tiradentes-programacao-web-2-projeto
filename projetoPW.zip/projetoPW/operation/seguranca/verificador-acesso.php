<?php 
    require_once("../../router.php");

    $user = $_POST['txtUser'];
    $senha = $_POST['pwSenha'];

    if(($user == "adm") && ($senha == "123")){
        sessaoLogin($user, $senha, 'adm');
        header("Location: ../../view/dashboard/index.php");
    }else if(ClienteDAO::login($user, $senha)){
        sessaoLogin($user, $senha, 'user');
        echo('logado');
        //header("Location: ../../view/index.php");
    } else {
        header("Location: ../../view/index.php");
    }

    function sessaoLogin($user, $senha, $tipo){
        session_start();
        session_unset();
        
        $_SESSION[$tipo.'-session'] = $user;
        $_SESSION[$tipo.'-senha-session'] = $senha;
    }
?>