<?php 
    session_start();

    if(($_SESSION['adm-session'] != "adm") || ($_SESSION['adm-senha-session'] != "123")){
        header("Location: ../../index.php");
    } 
    
    /*
    if(!ClienteDAO::login($_SESSION['user-session'], $_SESSION['user-senha-session'])){
        header("Location: ../../../index.php");
    }
    */
?>