<?php 
    session_start();

    if(isset($_SESSION['adm-session'])){
        if(($_SESSION['adm-session'] != "adm") || ($_SESSION['adm-senha-session'] != "123")){
            redireciona();
        }
    } else if(isset($_SESSION['user-session'])){
        if(ClienteDAO::login($_SESSION['user-session'], $_SESSION['user-senha-session']) == false){
            redireciona();
        }
    } else {
        redireciona();
    }

    function redireciona(){
        header("Location: ../../index.php");
    }
?>