<?php 
    class VendaController{
        public static function listaVenda($codCliente = null){
            $vendas = VendaDAO::listaVenda($codCliente);

            if(count($vendas) < 1){
                ViewController::getErro();
                return;
            }

            foreach($vendas as $venda){
                echo('
                <tr>
                    <td>'.$venda->getDataVenda().'</td>
                    <td>'.$venda->getCodVenda().'</td>
                    <td>'.$venda->getValorTotalVenda().'</td>
                    <td>'.$venda->getStatusVenda().'</td>
                    <td>
                        <a href="itens-compra.php?codVenda='.$venda->getCodVenda().'">
                            <button class="btn btn-primary">Listar Itens</button>
                        </a>
                    </td>
                </tr>
                ');
            }
        }

        public static function listaVendaDash($codCliente = null){
            $vendas = VendaDAO::listaVenda($codCliente);

            if(!$vendas){
                ViewController::getErro();
                return;
            }

            foreach($vendas as $venda){
                echo('
                <tr>
                    <td>'.$venda->getCodVenda().'</td>
                    <td>'.$venda->getCliente()->getNomeCliente().'</td>
                    <td>'.$venda->getCliente()->getEmailCliente().'</td>
                    <td>'.$venda->getCliente()->getCepCliente().'</td>
                    <td>'.$venda->getStatusVenda().'</td>
                    <td>
                    <td>
                        <a href="informacoes-venda-cliente.php?cod" class="form-control btn btn-warning"><i class="bx bx-detail"></i></a>
                    </td>
                </tr>
                ');
            }
        }
    }
?>