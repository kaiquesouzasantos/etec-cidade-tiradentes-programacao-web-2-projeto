<?php 
    class ViewDestaqueController{
        public static function retornaProdutosRecomendados(){
            $produtos = ProdutoDAO::listaProduto();
            shuffle($produtos);

            for($cont = 0; $cont < 3; $cont++){
                echo('
                <article class="featured__card">
                    <span class="featured__tag">Recomendado</span>
                    <img src="../operation/armazena/img-produto/'.$produtos[$cont]->getImgProduto().'" alt="" class="featured__img">
    
                    <div class="featured__data">
                        <h3 class="featured__title">'.$produtos[$cont]->getNomeProduto().'</h3>
                        <span class="featured__price">R$'.$produtos[$cont]->getPrecoProduto(true).'</span>
                    </div>
    
                    <a href="produtoPag.php?codProduto='.$produtos[$cont]->getCodProduto().'">
                        <button class="button featured__button">+ Carrinho</button>
                    </a>
                </article>
                ');
            }
        }

        public static function retornaProdutosNovos(){
            $produtos = ProdutoDAO::listaProduto();
            $categorias = CategoriaDAO::listaCategoria();

            foreach($categorias as $categoria){
                $produtoNovo = null;

                foreach($produtos as $produto){
                    if($produto->getCategoria()->getNomeCategoria() == $categoria->getNomeCategoria()){
                        $produtoNovo = $produto;
                    }
                }

                echo('
                <article class="new__card swiper-slide">
                    <span class="new__tag">Novo</span>
                    <img src="../operation/armazena/img-produto/'.$produtoNovo->getImgProduto().'" alt="" class="new__img">
    
                    <div class="new__data">
                        <h3 class="new__title">'.$produtoNovo->getNomeProduto().'</h3>
                        <span class="new__price">R$'.$produtoNovo->getPrecoProduto(true).'</span>
                    </div>
    
                    <a href="produtoPag.php?codProduto='.$produto->getCodProduto().'">
                        <button class="button new__button">+ Carrinho</button>
                    </a>
                </article>
                ');
            }
        }
    }
?>