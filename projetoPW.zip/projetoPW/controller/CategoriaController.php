<?php
    class CategoriaController{
        public static function verificaPreenchimento(){
            $campos = $_POST;

            foreach($campos as $campo){
                if(empty($campo)){
                    return false;
                }
            }

            return true;
        }

        public static function listaOpcoesCategoria(){
            $categorias = CategoriaDAO::listaCategoria();

            if(!$categorias){
                ViewController::getErro();
                return;
            }

            foreach($categorias as $categoria){
                echo('<option value="'.$categoria->getCodCategoria().'">'.$categoria->getNomeCategoria().'</option>');
            }
        }

        public static function listaCategoria($filtro = null){
            $categorias = CategoriaDAO::listaCategoria($filtro);

            if(!$categorias){
                ViewController::getErro();
                return;
            }

            foreach($categorias as $categoria){
                echo('
                <tr nome="'.$categoria->getNomeCategoria().'">    
                    <td>'.$categoria->getCodCategoria().'</td>
                    <td>'.$categoria->getNomeCategoria().'</td>
                    <td>
                        <a href="../../../../operation/deleta/deleta-categoria.php?codCategoria='.$categoria->getCodCategoria().'" class="form-control btn btn-danger"><i class="bx bx-trash-alt"></i></a>
                    </td>
                    <td>
                    <td>
                        <a href="atualiza-categoria.php?codCategoria='.$categoria->getCodCategoria().'" class="form-control btn btn-warning"><i class="bx bx-pencil"></i></a>
                    </td>
                </tr>');
            }
        }
    }
?>