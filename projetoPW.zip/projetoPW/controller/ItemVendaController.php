<?php
    class ItemVendaController {
        public static function listaItemCarrinho($codVenda){
            $itens = ItemVendaDAO::listaVenda($codVenda);

            foreach($itens as $item){
                echo('
                <tr>
                    <td>
                        <a href="../../operation/carrinho/remove-item.php?codVenda='.$codVenda.'&codProduto='.$item->getProduto()->getCodProduto().'">
                            <img src="assets/trash.svg" alt="icon">
                        </a> 
                    </td>
                    <td><img src="../../operation/armazena/img-produto/'.$item->getProduto()->getImgProduto().'" alt=""></td>
                    <td>'.$item->getProduto()->getNomeProduto().'</td>
                    <td>R$'.$item->getProduto()->getPrecoProduto(true).'</td>
                    <td>
                        <a href="/"> <img src="assets/minus.svg" alt="icon"></a>
                        <input type="number" value="'.$item->getQtdItemVenda().'">
                        <a href="#"><img src="assets/plus.svg" alt="icon"></a></td>
                    <td>R$'.$item->getSubtotalItemVenda().'</td>
                </tr>
                ');
            }
        }
    }
?>