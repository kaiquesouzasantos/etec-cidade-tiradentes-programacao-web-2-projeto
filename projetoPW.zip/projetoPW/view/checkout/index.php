<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Checkout</title>

  <!--
    - custom css link
  -->
  <link rel="stylesheet" href="style.css">

  <!--
    - google font link
  -->
  <link
    href="https://fonts.googleapis.com/css?family=Source+Sans+3:200,300,regular,500,600,700,800,900,200italic,300italic,italic,500italic,600italic,700italic,800italic,900italic"
    rel="stylesheet" />
</head>

<body>


  <!--
    - main container
  -->

  <main class="container">

    <h1 class="heading">
      <ion-icon name="card-outline"></ion-icon> Checkout
    </h1>

    <div class="item-flex">

      <!--
       - checkout section
      -->
      <section class="checkout">

        <h2 class="section-heading">Formas de pagamento</h2>

        <div class="payment-form">

          <div class="payment-method">

            <button class="method selected">
              <ion-icon name="card"></ion-icon>

              <span>Crédito</span>

              <ion-icon class="checkmark fill" name="checkmark-circle"></ion-icon>
            </button>

            <button class="method">
              <ion-icon name="logo-paypal"></ion-icon>

              <span>PayPal</span>

              <ion-icon class="checkmark" name="checkmark-circle-outline"></ion-icon>
            </button>

            <button class="method">
              <ion-icon name="barcode"></ion-icon>

              <span>Boleto</span>

              <ion-icon class="checkmark" name="checkmark-circle-outline"></ion-icon>
            </button>

          </div>

          <form action="#">

            <div class="cardholder-name">
              <label for="cardholder-name" class="label-default">Nome do cartão</label>
              <input type="text" name="cardholder-name" id="cardholder-name" class="input-default">
            </div>

            <div class="card-number">
              <label for="card-number" class="label-default">Numero do cartão</label>
              <input type="number" name="card-number" id="card-number" class="input-default">
            </div>

            <div class="input-flex">

              <div class="expire-date">
                <label for="expire-date" class="label-default"> Data de expiração</label>

                <div class="input-flex">

                  
                  <input type="number" name="month" id="expire-date" placeholder="12" min="1" max="12"
                    class="input-default">
                    /
                    <input type="number" name="year" id="expire-date" placeholder="2022" min="1" max="2050"
                    class="input-default">

                </div>
              </div>

              <div class="cvv">
                <label for="cvv" class="label-default">Código de segurança</label>
                <input type="number" name="cvv" id="cvv" class="input-default">
              </div>

              <div class="cvv">
                <label for="cvv" class="label-default">CPF ou CNPJ</label>
                <input type="number" name="cvv" id="cvv" class="input-default">
              </div>

            </div>

          </form>

        </div>

        <button class="btn btn-primary">
          <b>Efetuar pagamento</b> 
        </button>

      </section>


      <!-- PRODUTO 1---------------------------------------------------->
      <section class="cart">

        <div class="cart-item-box">

          <h2 class="section-heading">Carrinho</h2>

          <div class="product-card">

            <div class="card">

              <div class="img-box">
                <img src="./images/pro_002.png" alt="Green tomatoes" width="80px" class="product-img">
              </div>

              <div class="detail">

                <h4 class="product-name">Portofino Automatico 37</h4>

                <div class="wrapper">

                  <div class="product-qty">
                    <button id="decrement">
                      <ion-icon name="remove-outline"></ion-icon>
                    </button>

                    <span id="quantity">1</span>

                    <button id="increment">
                      <ion-icon name="add-outline"></ion-icon>
                    </button>
                  </div>

                  <div class="price">
                    R$ <span id="price">32.600</span>
                  </div>

                </div>

              </div>

              <button class="product-close-btn">
                <ion-icon name="close-outline"></ion-icon>
              </button>

            </div>

          </div>

          <!-- PRODUTO 2------------------------------------------------------------>
          <div class="product-card">

            <div class="card">

              <div class="img-box">
                <img src="./images/pro_02.png" alt="Cabbage" width="80px" class="product-img">
              </div>

              <div class="detail">

                <h4 class="product-name">Galapagus Islands</h4>

                <div class="wrapper">

                  <div class="product-qty">
                    <button id="decrement">
                      <ion-icon name="remove-outline"></ion-icon>
                    </button>

                    <span id="quantity">1</span>

                    <button id="increment">
                      <ion-icon name="add-outline"></ion-icon>
                    </button>
                  </div>

                  <div class="price">
                    R$ <span id="price">62.900</span>
                  </div>

                </div>

              </div>

              <button class="product-close-btn">
                <ion-icon name="close-outline"></ion-icon>
              </button>

            </div>

          </div>

          <!-- PRODUTO 3--------------------------------------------------------->
          <div class="product-card">

            <div class="card">

              <div class="img-box">
                <img src="./images/pro_03.png" alt="Green tomatoes" width="80px" class="product-img">
              </div>

              <div class="detail">

                <h4 class="product-name">Cronografo - EP</h4>

                <div class="wrapper">

                  <div class="product-qty">
                    <button id="decrement">
                      <ion-icon name="remove-outline"></ion-icon>
                    </button>

                    <span id="quantity">1</span>

                    <button id="increment">
                      <ion-icon name="add-outline"></ion-icon>
                    </button>
                  </div>

                  <div class="price">
                    R$ <span id="price">44.100</span>
                  </div>

                </div>

              </div>

              <button class="product-close-btn">
                <ion-icon name="close-outline"></ion-icon>
              </button>

            </div>

          </div>

        </div>
        

        <div class="wrapper">

          <div class="amount">

            <div class="subtotal">
              <span>Subtotal</span> <span>R$ <span id="subtotal">139.600</span></span>
            </div>

            <div class="shipping">
              <span>Frete</span><span id="shipping">Grátis</span>
            </div>

            <div class="total">
              <span>Total</span> <span>R$ <span id="total">139.600</span></span>
            </div>

          </div>

        </div>

      </section>

    </div>

  </main>






  <!--
    - custom js link
  -->
  <script src="./script.js"></script>

  <!--
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>

</html>