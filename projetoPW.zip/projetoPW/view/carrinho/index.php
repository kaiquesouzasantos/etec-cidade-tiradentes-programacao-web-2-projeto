<?php require_once("../../router.php");?>

<!DOCTYPE html>
<html lang="pt-br">
<?php ViewController::getHead("style.css"); ?>

<style>
    #quantidade {
        border: none; 
        text-align: center;
    }
</style>

<body>
    <!--==================== HEADER ====================-->
    <?php ViewController::getHeader("../index.php", "../login/"); ?>

    <main>
        <section id="cart" class="sectioln-p1">
            <table>
                <thead>
                    <tr>
                        <td>Remover</td>
                        <td>Imagem</td>
                        <td>Produto</td>
                        <td>Preço</td>
                        <td>Quantidade</td>
                        <td>Total</td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td> <a href=""><img src="assets/trash.svg" alt="icon"></a> </td>
                        <td><img src="assets/img/pro_01.png" alt=""></td>
                        <td>AVIADOR - ROYAL MACES</td>
                        <td>R$71.400</td>
                        <td>
                            <a href="/"> <img src="assets/minus.svg" alt="icon"></a>
                            <input type="number" value="1">
                            <a href="#"><img src="assets/plus.svg" alt="icon"></a></td>
                        <td>R$71.400</td>
                    </tr>
                    <tr>
                        <td> <a href=""><img src="assets/trash.svg" alt="icon"></a> </td>
                        <td><img src="assets/img/pro_16.png" alt=""></td>
                        <td>AVIADOR - MARK XVIII</td>
                        <td>R$38.900</td>
                        <td>
                            <a id="decremento" onclick="decrementeQuantidade()">
                                <img src="assets/minus.svg" alt="icon"> 
                            </a>
                            <input type="number" id="quantidade" value="1" min="1" max="5" readonly>
                            <a id="incremento" onclick="incrementeQuantidade()">
                                <img src="assets/plus.svg" alt="icon">
                            </a>
                        </td>
                        <td id="subtotal"></td>
                    </tr>
                </tbody>
            </table>
        </section>
        <br>

        <section id="cart-add" class="section-p1">
            <div id="coupon">
                <h3>Aplicar cupom</h3>
                <div>
                    <input type="text" placeholder="Entrar com seu cupom">
                    <button class="normal">Aplicar</button>
                </div>
            </div>
            <div id="subtotal">
                <h3><strong>Compra total</strong></h3>
                <table>
                    <tr>
                        <td>Valor do carrinho</td>
                        <td>R$189.700</td>
                    </tr>
                    <tr>
                        <td>Frete</td>
                        <td>Gratis</td>
                    </tr>
                    <tr>
                        <td><strong>Total</strong></td>
                        <td><strong>R$189.700</strong></td>
                    </tr>
                </table>
                <button class="normal">
                    <a href="../checkout/index.php">Prosseguir para checkout</a>
                </button>
            </div>
        </section>
    </main>

    <!--==================== FOOTER ====================-->
    <?php ViewController::getFooter(""); ?>

    <a href="#" class="scrollup" id="scroll-up">
        <i class='bx bx-up-arrow-alt scrollup__icon'></i></a>

    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script>
        function incrementeQuantidade() {
            let quantidade = parseInt(document.getElementById("quantidade").value)

            if(quantidade < parseInt(document.getElementById("quantidade").max)){
                document.getElementById("quantidade").value = quantidade + 1
            } else {
                document.getElementById("quantidade").value = quantidade
            }

            subtotal()
        }

        function decrementeQuantidade() {
            let quantidade = parseInt(document.getElementById("quantidade").value)

            if(quantidade > 1){
                document.getElementById("quantidade").value = quantidade - 1
            } else {
                document.getElementById("quantidade").value = 1
            }

            subtotal()
        }

        function subtotal(){
            
        }
    </script>
</body>

</html>