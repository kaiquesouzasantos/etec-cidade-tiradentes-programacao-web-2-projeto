<?php
    class DashboardDAO {
        private static function getConexao(){
            return Conexao::getConexao();
        }

        public static function retornaSumarizacao($comandoSQL) {
            try{
                $stmt = self::getConexao()->query($comandoSQL)->fetch(); 
                $retorno = number_format($stmt[0], 0, ",", ".");
                 
                if(empty($retorno)){
                    $retorno = 0;
                }
                return $retorno;
            } catch(Exception){
                return false;
            }
        }

        public static function retornaSumarizacaoMensal() {
            try{
                $retorno = "";   

                for($cont = 1; $cont <= 12; $cont++){
                    $retorno.= '500';

                    if($cont < 12){
                        $retorno.=',';
                    }
                        /*
                        self::retornaSumarizacao("
                            SELECT SUM(valortotalvenda) FROM tbvenda 
                                WHERE MONTH(datavenda) = ${cont}")
                        */
                }
                
                return $retorno;
            } catch(Exception){
                return false;
            }
        }
    }
?>