<?php 
    class ItemVendaDAO{
        private static function getConexao(){
            return Conexao::getConexao();
        }

        public static function cadastrarItemVenda($codVenda, $codProduto, $qtdItemVenda){
            $itemVenda = new ItemVenda();
            $itemVenda->setProduto(ProdutoDAO::retornaProduto($codProduto));
            $itemVenda->setQtdItemVenda($qtdItemVenda);
            $itemVenda->setSubtotalItemVenda();

            $comandoSQL = "INSERT INTO tbItemVenda(codVenda, codProduto, qntdItemVenda, subTotalItemVenda) 
                                VALUES (:codVenda, :codProduto, :quantidade, :subtotal)";
            
            $stmt = self::getConexao()->prepare($comandoSQL);
        
            $stmt->bindValue(":codVenda", $codVenda);
            $stmt->bindValue(":codProduto", $itemVenda->getProduto()->getCodProduto());
            $stmt->bindValue(":quantidade", $itemVenda->getQtdItemVenda());
            $stmt->bindValue(":subtotal", $itemVenda->getSubtotalItemVenda());

            $stmt->execute();

            return true;
        }

        public static function listaCarrinho($codVenda) {
            $itens = array();
            $comandoSQL = "SELECT * FROM tbItemVenda WHERE codVenda = ${codVenda}";

            try{
                $stmt = self::getConexao()->query($comandoSQL)->fetchAll();

                if(count($stmt) < 0){
                    return false;
                }

                foreach($stmt as $item){
                    $objeto = new ItemVenda();
                    $objeto->construct_full(
                        $item['codItemvenda'], VendaDAO::retornaVenda($item['codVenda']), 
                        ProdutoDAO::retornaProduto($item['codProduto']), $item['qntdItemVenda']
                    );
                    
                    array_push($itens, $objeto);
                }

                return $itens;
            } catch(Exception){
                return false;
            }
        }

        public static function listaVenda($codVenda) {
            $itens = array();
            $comandoSQL = "SELECT * FROM tbItemVenda WHERE codVenda = ${codVenda}";

            try{
                $stmt = self::getConexao()->query($comandoSQL)->fetchAll();

                if(count($stmt) < 1){
                    return false;
                }

                foreach($stmt as $item){
                    $objeto = new ItemVenda();
                    $objeto->construct_full(
                        $item['codItemvenda'], VendaDAO::retornaVenda($item['codVenda']), 
                        ProdutoDAO::retornaProduto($item['codProduto']), $item['qntdItemVenda']
                    );
                    
                    array_push($itens, $objeto);
                }

                return $itens;
            } catch(Exception){
                return false;
            }
        }
    }
?>