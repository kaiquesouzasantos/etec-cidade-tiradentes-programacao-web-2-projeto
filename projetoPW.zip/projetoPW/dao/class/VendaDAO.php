<?php
    class VendaDAO {
        private static function getConexao(){
            return Conexao::getConexao();
        }

        public static function retornaCarrinho($codCliente) {
            try{
                $stmt = self::getConexao()->prepare("CALL spRetornaVenda(${codCliente}, @p1)")->execute();
                $stmt = self::getConexao()->query("SELECT * FROM tbvenda WHERE codCliente = ${codCliente} AND statusVenda = 0")->fetch();
            
                return $stmt['codVenda'];
            } catch(Exception){
                return false;
            }
        }

        public static function retornaVenda($codVenda) {
            try{
                $stmt = self::getConexao()->query("SELECT * FROM tbvenda WHERE codVenda = ${codVenda}")->fetch();
                
                $venda = new Venda();
                $venda->construct_full(
                    $stmt['codVenda'], $stmt['dataVenda'], $stmt['valorTotalvenda'],
                    $stmt['statusVenda'], ClienteDAO::retornaCliente($stmt['codCliente'])
                );

                return $venda;
            } catch(Exception){
                return false;
            }
        }

        public static function listaVenda($codCliente = null) {
            $vendas = array();
            $comandoSQL = "SELECT * FROM tbvenda";

            if(isset($codCliente)){
                $comandoSQL = "SELECT * FROM tbvenda WHERE codCliente = ${codCliente} AND statusVenda <> 0";
            } 
 
            try{
                $stmt = self::getConexao()->query($comandoSQL)->fetchAll();

                if(count($stmt) < 1){
                    return false;
                }

                foreach($stmt as $venda){
                    $objeto = new Venda();
                    $objeto->construct_full(
                        $venda['codVenda'], $venda['dataVenda'], $venda['valorTotalvenda'],
                        $venda['statusVenda'], ClienteDAO::retornaCliente($venda['codCliente'])
                    );
                    
                    array_push($vendas, $objeto);
                }

                return $vendas;
            } catch(Exception){
                return false;
            }
        }
    }
?>