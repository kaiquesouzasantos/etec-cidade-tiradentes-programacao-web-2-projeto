<?php 
    require_once("../../router.php");
    require_once("../../operation/seguranca/verificador-permanencia.php");

    $codCarrinho = VendaDAO::retornaCarrinho(
        ClienteDAO::retornaCliente("", $_SESSION['user-session'])->getCodCliente()
    );

    $venda = VendaDAO::retornaVenda($codCarrinho);
?>

<!DOCTYPE html>
<html lang="pt-br">
<?php ViewController::getHead("style.css"); ?>

<style>
    #quantidade {
        border: none;
        text-align: center;
    }

    input {
        text-align: center;
        border: none;
    }

    a {
        color: aliceblue;
    }
</style>

<body>
    <!--==================== HEADER ====================-->
    <?php ViewController::getHeader("../index.php", "../../operation/seguranca/verificador-logado.php"); ?>

    <main>
        <section id="cart" class="sectioln-p1">
            <table>
                <thead>
                    <tr>
                        <td>Remover</td>
                        <td>Imagem</td>
                        <td>Produto</td>
                        <td>Preço</td>
                        <td>Quantidade</td>
                        <td>Total</td>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        ItemVendaController::listaItemCarrinho($codCarrinho);
                    ?>
                </tbody>
            </table>
        </section>
        <br>

        <section id="cart-add" class="section-p1">
            <div id="coupon">
                <h3>Aplicar cupom</h3>
                <div>
                    <input type="text" placeholder="Entrar com seu cupom">
                    <button class="normal">Aplicar</button>
                </div>
            </div>
            <div id="subtotal">
                <h3><strong>Compra Total</strong></h3>
                <table>
                    <tr>
                        <td>Frete</td>
                        <td>Gratis</td>
                    </tr>
                    <tr>
                        <td><strong>Total</strong></td>
                        <td><strong>R$<?php echo($venda->getValorTotalVenda(true))?></strong></td>
                    </tr>
                </table>
                <a href="../checkout/index.php?codVenda=<?php echo($codCarrinho); ?>">
                    <button class="normal">
                        Prosseguir para checkout
                    </button>
                </a>
            </div>
        </section>
    </main>

    <!--==================== FOOTER ====================-->
    <?php ViewController::getFooter(""); ?>

    <a href="#" class="scrollup" id="scroll-up">
        <i class='bx bx-up-arrow-alt scrollup__icon'></i></a>

    <script src="../assets/js/swiper-bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
    <script src="assets/js/script.js"></script>
</body>

</html>