<?php 
  require_once("../../router.php");
  require_once("dist/php/ViewDashController.php");
  require_once("../../operation/seguranca/verificador-permanencia.php");
?>

<!DOCTYPE html>
<html lang="pt-BR">
<?php ViewDashController::getHeadDash("Dashboard", ""); ?>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">
    <!--==================== NAV MAIN ====================-->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
          <a href="index.php" class="nav-link">Home</a>
        </li>
      </ul>

      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" data-widget="fullscreen" href="#" role="button">
            <i class="fas fa-expand-arrows-alt"></i>
          </a>
        </li>
      </ul>
    </nav>

    <!--==================== SIDEBAR ====================-->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
      <a href="index.php" class="brand-link">
        <span class="brand-text font-weight-light">DEV. WATCH</span>
      </a>

      <!--==================== SIDEBAR - NAV ====================-->
      <?php ViewDashController::getNav("", "pages/forms/", "pages/lists/"); ?>
    </aside>

    <div class="content-wrapper">
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Dashboard</h1>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <!--==================== MAIN ====================-->
      <section class="content">
        <div class="container-fluid">
          <!--==================== SUMARIZAÇÃO ====================-->
          <div class="row">
            <div class="col-lg-3 col-6">
              <div class="small-box bg-info">
                <div class="inner">
                  <h3>
                    <?php 
                      echo(DashboardDAO::retornaSumarizacao("SELECT COUNT(codvenda) FROM tbvenda")); 
                    ?>
                  </h3>
                  <p>Total de Vendas</p>
                </div>
                <div class="icon">
                  <i class="ion ion-bag"></i>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-6">
              <div class="small-box bg-success">
                <div class="inner">
                  <h3>
                    <?php 
                      echo(DashboardDAO::retornaSumarizacao("SELECT COUNT(codproduto) FROM tbproduto")); 
                    ?>
                  </h3>
                  <p>Total de Produtos</p>
                </div>
                <div class="icon">
                  <i class="ion ion-stats-bars"></i>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-6">
              <div class="small-box bg-warning">
                <div class="inner">
                  <h3>
                    <?php 
                      echo(DashboardDAO::retornaSumarizacao("SELECT COUNT(codcliente) FROM tbcliente")); 
                    ?>
                  </h3>
                  <p>Total de Clientes</p>
                </div>
                <div class="icon">
                  <i class="ion ion-person"></i>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-6">
              <div class="small-box bg-danger">
                <div class="inner">
                  <h3>
                    <?php 
                      echo("R$".DashboardDAO::retornaSumarizacao("SELECT SUM(valorTotalvenda) FROM tbvenda")); 
                    ?>
                  </h3>
                  <p>Total de Faturamento</p>
                </div>
                <div class="icon">
                  <i class="ion ion-pie-graph"></i>
                </div>
              </div>
            </div>
          </div>

          <input type="hidden" id="arraymeses" value="<?php echo(DashboardDAO::retornaSumarizacaoMensal()); ?>">
          <!--==================== GRAFICO ====================-->
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header">
                  <h5 class="card-title">Gráfico de Vendas</h5>
                </div>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-12">
                      <p class="text-center">
                        <strong>Janeiro/2022 - Dezembro/2022</strong>
                      </p>

                      <div class="chart">
                        <canvas id="salesChart" height="180" style="height: 180px;"></canvas>
                      </div>
                    </div>
                  </div>
                </div>

                <!--==================== SUMARIZAÇÃO ====================-->
                <div class="card-footer">
                  <div class="row">
                    <div class="col-sm-3 col-6">
                      <div class="description-block border-right">
                        <h5 class="description-header">
                          <?php 
                            echo("R$".DashboardDAO::retornaSumarizacao("SELECT MAX(precoproduto) FROM tbproduto")); 
                          ?>
                        </h5>
                        <span class="description-text">PRODUTO MAIS CARO</span>
                      </div>
                    </div>
                    <div class="col-sm-3 col-6">
                      <div class="description-block border-right">
                        <h5 class="description-header">
                          <?php 
                            echo("R$".DashboardDAO::retornaSumarizacao("SELECT MIN(precoproduto) FROM tbproduto")); 
                          ?>
                        </h5>
                        <span class="description-text">PRODUTO MAIS BARATO</span>
                      </div>
                    </div>
                    <div class="col-sm-3 col-6">
                      <div class="description-block border-right">
                        <h5 class="description-header">
                          <?php 
                            echo("R$".DashboardDAO::retornaSumarizacao("SELECT MAX(valortotalvenda) FROM tbvenda")); 
                          ?>
                        </h5>
                        <span class="description-text">MAIOR VENDA</span>
                      </div>
                    </div>
                    <div class="col-sm-3 col-6">
                      <div class="description-block">
                        <h5 class="description-header">
                          <?php 
                            echo("R$".DashboardDAO::retornaSumarizacao("SELECT MIN(valortotalvenda) FROM tbvenda")); 
                          ?>
                        </h5>
                        <span class="description-text">MENOR VENDA</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
      </section>
    </div>
    <!--==================== FOOTER ====================-->
    <?php ViewDashController::getFooter(); ?>

    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="plugins/jquery-ui/jquery-ui.min.js"></script>
    <script>
      $.widget.bridge('uibutton', $.ui.button)
    </script>
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="plugins/chart.js/Chart.min.js"></script>
    <script src="plugins/sparklines/sparkline.js"></script>
    <script src="plugins/jqvmap/jquery.vmap.min.js"></script>
    <script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
    <script src="plugins/jquery-knob/jquery.knob.min.js"></script>
    <script src="plugins/moment/moment.min.js"></script>
    <script src="plugins/daterangepicker/daterangepicker.js"></script>
    <script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="plugins/summernote/summernote-bs4.min.js"></script>
    <script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
    <script src="dist/js/adminlte.js"></script>
    <script src="dist/js/demo.js"></script>
    <script src="dist/js/dashboard2.js"></script>
</body>

</html>