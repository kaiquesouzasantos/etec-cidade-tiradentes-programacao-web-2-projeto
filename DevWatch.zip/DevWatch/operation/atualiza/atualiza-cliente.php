<?php
    require_once("../../router.php");

    $img = $_FILES['fotoCliente'];

    if(empty($img['name'])){
        $img = ClienteDAO::retornaCliente($_POST['codCliente'])->getImgCliente();
    } else {
        $img = ClienteController::getDestino();
    }

    if(ClienteController::verificaPreenchimento()){
        ClienteDAO::atualizarCliente(
            $_POST['codCliente'], $_POST['nomeCliente'], $_POST['cpfCliente'], $_POST['emailCliente'],
            $_POST['logradouroCliente'], $_POST['numeroCliente'], $_POST['complementoCliente'],
            $_POST['bairroCliente'], $_POST['cidadeCliente'], $_POST['UFCliente'],
            $_POST['CEPCliente'], $img, $_POST['senhaCliente']
        );
    }

    //header("Location: ../../view/usuario/conta/index.php");
?>