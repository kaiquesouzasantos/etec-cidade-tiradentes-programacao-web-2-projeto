<?php
    require_once("../../router.php");

    $img = $_FILES['imgProduto'];

    if(empty($img['name'])){
        $img = ProdutoDAO::retornaProduto($_POST['codigoProduto'])->getImgProduto();
    } else {
        $img = ProdutoController::getDestino();
    }

    if(ProdutoController::verificaPreenchimento()){
        ProdutoDAO::atualizarProduto(
            $_POST['codigoProduto'], $_POST['nomeProduto'], $_POST['precoProduto'], $_POST['descricaoProduto'],
            $_POST['quantidadeProduto'], $_POST['codigoCategoria'], $img
        );
    }

    header("Location: ../../view/dashboard/pages/forms/cadastro-produto.php");
?>