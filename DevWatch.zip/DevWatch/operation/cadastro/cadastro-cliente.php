<?php
    require_once("../../router.php");

    if(ClienteController::verificaPreenchimento() && ClienteController::validaCPF($_POST['cpfCliente'])){
        ClienteDAO::cadastrarCliente(
            $_POST['nomeCliente'], $_POST['cpfCliente'], $_POST['emailCliente'],
            $_POST['logradouroCliente'], $_POST['numeroCliente'], $_POST['complementoCliente'],
            $_POST['bairroCliente'], $_POST['cidadeCliente'], $_POST['UFCliente'],
            $_POST['CEPCliente'], ClienteController::getDestino(), $_POST['senhaCliente']
        );

        header("Location: ../../view/usuario/login/formulario-login.php");
    } else {
        header("Location: ../../view/usuario/cadastro/formulario-cadastro-cliente-erro.php");
    }

?>