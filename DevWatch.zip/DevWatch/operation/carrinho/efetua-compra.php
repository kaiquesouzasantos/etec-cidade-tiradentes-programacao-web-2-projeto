<?php
    require_once("../../router.php");

    if(isset($_GET['codVenda'])){
        VendaDAO::finalizaVenda($_GET['codVenda']);
    }

    header("Location: ../../view/index.php");
?>