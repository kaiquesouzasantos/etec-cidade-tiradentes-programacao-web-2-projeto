<?php
    require_once("../../router.php");

    if(isset($_GET['codVenda'])){
        VendaDAO::cancelaVenda($_GET['codVenda']);
    }

    header("Location: ../../view/dashboard/pages/lists/informacoes-venda-cliente.php?codVenda=".$_GET['codVenda']);
?>