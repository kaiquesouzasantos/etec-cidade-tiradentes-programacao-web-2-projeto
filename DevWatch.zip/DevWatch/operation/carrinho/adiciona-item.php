<?php
    require_once("../../router.php");

    if(empty($_GET['codVenda']) or empty($_GET['quantidade'])){
        header("Location: ../../view/produtoPag.php?codProduto=".$_GET['codProduto']);
    } else if(empty($_GET['codProduto'])){
        header("Location: ../../index.php");
    } else {
        ItemVendaDAO::cadastrarItemVenda(
            $_GET['codVenda'], $_GET['codProduto'], $_GET['quantidade']
        );
        header("Location: ../../view/produtoPag.php?codProduto=".$_GET['codProduto']);
    }
?>