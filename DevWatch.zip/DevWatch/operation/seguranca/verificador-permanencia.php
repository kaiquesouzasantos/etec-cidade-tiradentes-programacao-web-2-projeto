<?php 
    session_start();

    if(isset($_SESSION['adm-session'])){
        if(($_SESSION['adm-session'] != "adm") || ($_SESSION['adm-senha-session'] != "123")){
            redireciona();
        }
    } else if(isset($_SESSION['user-session'])){
        if(!ClienteDAO::login($_SESSION['user-session'], $_SESSION['user-senha-session'])){
            redireciona();
        }
    } else {
        redireciona();
    }

    function redireciona(){
        header("Location: ../../view/usuario/login/formulario-login.php");
    }
?>