<?php 
    class ItemVendaDAO{
        private static function getConexao(){
            return Conexao::getConexao();
        }

        private static function verificaExistente($codVenda, $codProduto){
            $stmt = self::getConexao()->query("
                SELECT * FROM tbItemvenda WHERE codVenda = ${codVenda} AND codProduto = ${codProduto}
            ")->fetch();

            if(empty($stmt['codItemvenda'])){
                return false;
            }

            return $stmt['codItemvenda'];
        }

        public static function atualizaSubTotal($codItemVenda){
            $stmt = self::getConexao()->prepare("CALL spTgSubTotalVenda(${codItemVenda}, @p1, @p2)")->execute();
        }

        public static function removeItem($codVenda, $codProduto){
            $stmt = self::getConexao()->prepare("
                DELETE FROM tbItemvenda WHERE codVenda = ${codVenda} AND codProduto = ${codProduto} 
            ")->execute();

            VendaDAO::atualizaTotal($codVenda);
        }

        public static function cadastrarItemVenda($codVenda, $codProduto, $qtdItemVenda){
            $itemVenda = new ItemVenda();
            $itemVenda->setProduto(ProdutoDAO::retornaProduto($codProduto));
            $itemVenda->setQtdItemVenda($qtdItemVenda);
            $itemVenda->setSubtotalItemVenda();

            if(!self::verificaExistente($codVenda, $codProduto)){
                $comandoSQL = "INSERT INTO tbItemVenda(codVenda, codProduto, qntdItemVenda, subTotalItemVenda) 
                VALUES (:codVenda, :codProduto, :quantidade, :subtotal)";

                $stmt = self::getConexao()->prepare($comandoSQL);
                        
                $stmt->bindValue(":codVenda", $codVenda);
                $stmt->bindValue(":codProduto", $itemVenda->getProduto()->getCodProduto());
                $stmt->bindValue(":quantidade", $itemVenda->getQtdItemVenda());
                $stmt->bindValue(":subtotal", $itemVenda->getSubtotalItemVenda());

                $stmt->execute();
            } else {
                $codItemVenda = self::verificaExistente($codVenda, $codProduto);

                $stmt = self::getConexao()->prepare(
                    "UPDATE tbItemvenda SET qntdItemVenda = qntdItemVenda + ${qtdItemVenda} 
                        WHERE codItemvenda = ".$codItemVenda)->execute();

                self::atualizaSubTotal($codItemVenda);
            }

            VendaDAO::atualizaTotal($codVenda);
            
            return true;
        }

        public static function incrementaItem($codVenda, $codProduto){
            $stmt = self::getConexao()->prepare("
                UPDATE tbItemvenda SET qntdItemVenda = qntdItemVenda + 1 WHERE codVenda = ${codVenda} AND codProduto = ${codProduto} 
            ")->execute();

            ItemVendaDAO::atualizaSubTotal(self::verificaExistente($codVenda, $codProduto));
            VendaDAO::atualizaTotal($codVenda);
        }

        public static function decrementaItem($codVenda, $codProduto){
            $stmt = self::getConexao()->prepare("
                UPDATE tbItemvenda SET qntdItemVenda = qntdItemVenda - 1 
                    WHERE 
                        codVenda = ${codVenda} AND codProduto = ${codProduto} AND
                        qntdItemVenda > 0
            ")->execute();

            ItemVendaDAO::atualizaSubTotal(self::verificaExistente($codVenda, $codProduto));
            VendaDAO::atualizaTotal($codVenda);
        }

        public static function listaCarrinho($codVenda) {
            $itens = array();
            $comandoSQL = "SELECT * FROM tbItemVenda WHERE codVenda = ${codVenda} AND qntdItemVenda > 0";

            try{
                $stmt = self::getConexao()->query($comandoSQL)->fetchAll();

                if(count($stmt) < 0){
                    return false;
                }

                foreach($stmt as $item){
                    $objeto = new ItemVenda();
                    $objeto->construct_full(
                        $item['codItemvenda'], VendaDAO::retornaVenda($item['codVenda']), 
                        ProdutoDAO::retornaProduto($item['codProduto']), $item['qntdItemVenda']
                    );
                    
                    array_push($itens, $objeto);
                }

                return $itens;
            } catch(Exception){
                return false;
            }
        }

        public static function listaVenda($codVenda) {
            $itens = array();
            $comandoSQL = "SELECT * FROM tbItemVenda WHERE codVenda = ${codVenda} AND qntdItemVenda > 0";

            try{
                $stmt = self::getConexao()->query($comandoSQL)->fetchAll();

                if(count($stmt) < 1){
                    return false;
                }

                foreach($stmt as $item){
                    $objeto = new ItemVenda();
                    $objeto->construct_full(
                        $item['codItemvenda'], VendaDAO::retornaVenda($item['codVenda']), 
                        ProdutoDAO::retornaProduto($item['codProduto']), $item['qntdItemVenda']
                    );
                    
                    array_push($itens, $objeto);
                }

                return $itens;
            } catch(Exception){
                return false;
            }
        }
    }
?>