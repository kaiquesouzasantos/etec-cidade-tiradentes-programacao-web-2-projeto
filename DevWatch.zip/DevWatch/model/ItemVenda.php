<?php
    class ItemVenda{
        private $codItemVenda, $venda, $produto, $qtdItemVenda, $subtotalItemVenda;

        public function construct_min($venda, $produto, $qtdItemVenda){
            $this->venda  = $venda;
            $this->produto  = $produto;
            $this->qtdItemVenda  = $qtdItemVenda;
            $this->setSubtotalItemVenda();
        }

        public function construct_full($codItemVenda, $venda, $produto, $qtdItemVenda){
            $this->codItemVenda = $codItemVenda;
            $this->construct_min($venda, $produto, $qtdItemVenda);
        }
        
        public function getCodItemVenda(){return $this->codItemVenda;}
        public function setCodItemVenda($codItemVenda){$this->codItemVenda = $codItemVenda;}
        
        // venda -> Venda OBJ
        public function getVenda() : Venda {return $this->venda;}
        public function setVenda($venda){$this->venda = $venda;}
        
        // produto -> Produto OBJ
        public function getProduto() : Produto {return $this->produto;}
        public function setProduto($produto){$this->produto = $produto;}

        public function getQtdItemVenda(){return $this->qtdItemVenda;}
        public function setQtdItemVenda($qtdItemVenda){$this->qtdItemVenda = $qtdItemVenda;}

        public function getSubtotalItemVenda($formata = false){
            if($formata){
                return number_format($this->subtotalItemVenda, 0, ',', '.');
            }

            return $this->subtotalItemVenda;
        }
        public function setSubtotalItemVenda(){
            $this->subtotalItemVenda = $this->getProduto()->getPrecoProduto() * $this->qtdItemVenda;
        }
    }
?>