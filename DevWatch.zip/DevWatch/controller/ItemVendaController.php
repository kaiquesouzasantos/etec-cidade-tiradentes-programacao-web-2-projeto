<?php
    class ItemVendaController {
        public static function listaItemCarrinho($codVenda){
            $itens = ItemVendaDAO::listaVenda($codVenda);

            if(!$itens){
                return;
            }

            foreach($itens as $item){
                echo('
                <tr>
                    <td>
                        <a href="../../operation/carrinho/remove-item.php?codVenda='.$codVenda.'&codProduto='.$item->getProduto()->getCodProduto().'">
                            <img src="assets/trash.svg" alt="icon">
                        </a> 
                    </td>
                    <td><img src="../../operation/armazena/img-produto/'.$item->getProduto()->getImgProduto().'" alt=""></td>
                    <td>'.$item->getProduto()->getNomeProduto().'</td>
                    <td>R$'.$item->getProduto()->getPrecoProduto(true).'</td>
                    <td>
                        <a href="#"> <img src="assets/minus.svg" alt="icon"></a>
                        <input type="number" value="'.$item->getQtdItemVenda().'">
                        <a href="#"><img src="assets/plus.svg" alt="icon"></a></td>
                    <td>R$'.$item->getSubtotalItemVenda(true).'</td>
                </tr>
                ');
            }
        }

        public static function listaItemCarrinhoCheckout($codVenda){
            $itens = ItemVendaDAO::listaVenda($codVenda);

            foreach($itens as $item){
                echo('
                <div class="product-card">
                    <div class="card">
                    <div class="img-box">
                        <img src="./images/pro_02.png" alt="Cabbage" width="80px" class="product-img">
                    </div>
                    <div class="detail">
                        <h4 class="product-name">'.$item->getProduto()->getNomeProduto().'</h4>
                        <div class="wrapper">
                        <div class="product-qty">
                            <button id="decrement">
                            <ion-icon name="remove-outline"></ion-icon>
                            </button>
                            <span id="quantity">'.$item->getQtdItemVenda().'</span>
                            <button id="increment">
                            <ion-icon name="add-outline"></ion-icon>
                            </button>
                        </div>
                        <div class="price">
                            R$ <span id="price">'.$item->getSubtotalItemVenda(true).'</span>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                ');
            }            
        }

        public static function listaItemVenda($codVenda){
            $itens = ItemVendaDAO::listaVenda($codVenda);

            if(!$itens){
                return;
            }

            foreach($itens as $item){
                echo('
                <tr>
                    <td><img src="../../../operation/armazena/img-produto/'.$item->getProduto()->getImgProduto().'" alt=""></td>
                    <td>'.$item->getProduto()->getNomeProduto().'</td>
                    <td>R$'.$item->getProduto()->getPrecoProduto(true).'</td>
                    <td>'.$item->getQtdItemVenda().'</td>
                    <td>R$'.$item->getSubtotalItemVenda(true).'</td>
                </tr>
                ');
            }
        }

        public static function listaItemVendaDash($codVenda){
            $itens = ItemVendaDAO::listaVenda($codVenda);

            if(!$itens){
                return;
            }

            foreach($itens as $item){
                echo('
                <tr>
                    <td>'.$item->getProduto()->getCodProduto().'</td>
                    <td>'.$item->getProduto()->getNomeProduto(true).'</td>
                    <td>'.$item->getProduto()->getCategoria()->getNomeCategoria().'</td>
                    <td>'.$item->getQtdItemVenda().'</td>
                    <td>R$'.$item->getProduto()->getPrecoProduto(true).'</td>
                    <td>R$'.$item->getSubtotalItemVenda(true).'</td>
                <tr>
                ');
            }
        }
    }
?>