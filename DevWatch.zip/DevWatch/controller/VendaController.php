<?php 
    class VendaController{
        public static function listaVenda($codCliente = null){
            $vendas = VendaDAO::listaVenda($codCliente);

            foreach($vendas as $venda){
                echo('
                <tr>
                    <td>'.$venda->getDataVenda().'</td>
                    <td>'.$venda->getCodVenda().'</td>
                    <td>'.$venda->getValorTotalVenda(true).'</td>
                    <td>'.$venda->getStatusVenda(true).'</td>
                    <td>
                        <a href="itens-compra.php?codVenda='.$venda->getCodVenda().'">
                            <button class="btn btn-primary">Listar Itens</button>
                        </a>
                    </td>
                </tr>
                ');
            }
        }

        public static function listaVendaDash($codCliente = null){
            $vendas = VendaDAO::listaVenda($codCliente);

            if(!$vendas){
                return;
            }

            foreach($vendas as $venda){
                echo('
                <tr>
                    <td>'.$venda->getCodVenda().'</td>
                    <td>'.$venda->getDataVenda().'</td>
                    <td>R$'.$venda->getValorTotalVenda(true).'</td>
                    <td>'.$venda->getCliente()->getCepCliente().'</td>
                    <td>'.$venda->getStatusVenda(true).'</td>
                    <td>
                    <td>
                        <a href="informacoes-venda-cliente.php?codVenda='.$venda->getCodVenda().'" class="form-control btn btn-warning"><i class="bx bx-detail"></i></a>
                    </td>
                </tr>
                ');
            }
        }
    }
?>