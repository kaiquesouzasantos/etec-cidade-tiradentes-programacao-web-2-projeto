<?php
    class ClienteController{
        public static function getDestino(){
            $nome = $_FILES['fotoCliente']['name'];
            $destino = '../armazena/img-cliente/'.$nome;
            $arquivo_tmp = $_FILES['fotoCliente']['tmp_name'];
            move_uploaded_file($arquivo_tmp, $destino); 
    
            return $nome;
        }

        public static function verificaPreenchimento(){
            $campos = $_POST;

            foreach($campos as $campo){
                if(empty($campo)){
                    return false;
                }
            }

            return true;
        }

        public static function validaCPF($cpf){
            $cpf = preg_replace( '/[^0-9]/is', '', $cpf );
            if (strlen($cpf) != 11) {return false;}	
            $digitos = substr($cpf, 0, 9);
    
            if(
                $digitos == "111111111" && $digitos == "222222222" && $digitos == "333333333"
                && $digitos == "444444444" && $digitos == "5555555555" && $digitos == "666666666"
                && $digitos == "777777777" && $digitos == "888888888" && $digitos == "999999999"
            ) return false;
    
            function calc_digitos_posicoes( $digitos, $posicoes = 10, $soma_digitos = 0 ) {
                for($i = 0; $i < strlen($digitos); $i++) {
                    $soma_digitos = $soma_digitos + ($digitos[$i] * $posicoes);                    
                    $posicoes--;
                }
        
                $soma_digitos = $soma_digitos % 11;
        
                if ($soma_digitos < 2) {$soma_digitos = 0;
                } else {$soma_digitos = 11 - $soma_digitos;}
    
                return $digitos . $soma_digitos;            
            }
    
            $novo_cpf = calc_digitos_posicoes($digitos );
            $novo_cpf = calc_digitos_posicoes($novo_cpf, 11 );
            
            return $novo_cpf === $cpf;
        }

        public static function listaCliente($filtro = null){
            $clientes = ClienteDAO::listaCliente($filtro);

            foreach($clientes as $cliente){
                echo('
                <tr>
                    <td>'.$cliente->getCodCliente().'</td>
                    <td>'.$cliente->getNomeCliente().'</td>
                    <td>'.$cliente->getEmailCliente().'</td>
                    <td>'.$cliente->getUfCliente().'</td>
                    <td>'.$cliente->getAtividadeCliente().'</td>
                    <td>
                        <a href="../../../../operation/deleta/desativa-cliente.php?codCliente='.$cliente->getCodCliente().'" class="form-control btn btn-danger"><i class="bx bxs-user-x"></i></a>
                    </td>
                    <td>
                    <td>
                        <a href="listagem-venda-cliente.php?codCliente='.$cliente->getCodCliente().'" class="form-control btn btn-warning"><i class="bx bx-detail"></i></a>
                    </td>
                </tr>
                ');
            }
        }

        public static function listaClienteVenda(){
            $clientes = ClienteDAO::listaCliente();

            foreach($clientes as $cliente){
                echo('
                <tr>
                    <td>'.$cliente->getCodCliente().'</td>
                    <td>'.$cliente->getNomeCliente().'</td>
                    <td>'.$cliente->getEmailCliente().'</td>
                    <td>'.$cliente->getCepCliente().'</td>
                    <td>'.$cliente->getAtividadeCliente().'</td>
                    <td>
                    <td>
                        <a href="informacoes-venda-cliente.php" class="form-control btn btn-warning"><i class="bx bx-detail"></i></a>
                    </td>
                </tr>
                ');
            }
        }
    }
?>