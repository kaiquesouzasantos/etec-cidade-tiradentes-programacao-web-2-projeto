<?php 
    $produtos = [
            ["id"=>1, "nome"=>"Cronografo", "preco"=>"31.500", "img"=>"pro_01", "categoria"=>"Aquat"],
            ["id"=>2, "nome"=>"Galapagus Islands", "preco"=>"62.900", "img"=>"pro_02", "categoria"=>"Aquat"],
            ["id"=>3, "nome"=>"Cronografo - EP", "preco"=>"44.100", "img"=>"pro_03", "categoria"=>"Aquat"],
            ["id"=>4, "nome"=>"Expedition Jacques", "preco"=>"27.800", "img"=>"pro_04", "categoria"=>"Aquat"],
            ["id"=>5, "nome"=>"Cronograco - IWC", "preco"=>"43.200", "img"=>"pro_05", "categoria"=>"Aquat"],
            ["id"=>6, "nome"=>"Aviador - Mark xviii", "preco"=>"38.900", "img"=>"pro_06", "categoria"=>"Aquat"],

            ["id"=>7, "nome"=>"Calendario Perpetuo", "preco"=>"246.100", "img"=>"pro_07", "categoria"=>"Porto"],
            ["id"=>8, "nome"=>"Calendario Anual", "preco"=>"180.900", "img"=>"pro_08", "categoria"=>"Porto"],
            ["id"=>9, "nome"=>"Cronografo", "preco"=>"108.900", "img"=>"pro_09", "categoria"=>"Porto"],
            ["id"=>10, "nome"=>"Cronografo - EG", "preco"=>"47.900", "img"=>"pro_10", "categoria"=>"Porto"],
            ["id"=>11, "nome"=>"Cronografo - YC", "preco"=>"76.500", "img"=>"pro_11", "categoria"=>"Porto"],
            ["id"=>12, "nome"=>"Cronografo - LX", "preco"=>"73.200", "img"=>"pro_12", "categoria"=>"Porto"],

            ["id"=>13, "nome"=>"Big Pilot 43", "preco"=>"54.700", "img"=>"pro_13", "categoria"=>"Metal"],
            ["id"=>14, "nome"=>"Aviador 41", "preco"=>"43.300", "img"=>"pro_14", "categoria"=>"Metal"],
            ["id"=>15, "nome"=>"Aviador 41 - Mark xviii", "preco"=>"31.500", "img"=>"pro_15", "categoria"=>"Metal"],
            ["id"=>16, "nome"=>"Big Pilot 13", "preco"=>"74.800", "img"=>"pro_16", "categoria"=>"Metal"],
            ["id"=>17, "nome"=>"Big Pilot 37", "preco"=>"38.800", "img"=>"pro_17", "categoria"=>"Metal"],
            ["id"=>18, "nome"=>"Aviador 39 - AMG", "preco"=>"28.700", "img"=>"pro_18", "categoria"=>"Metal"],

            ["id"=>19, "nome"=>"TG - Aviador 41", "preco"=>"47.900", "img"=>"pro_19", "categoria"=>"Aviador"],
            ["id"=>20, "nome"=>"TG - WoodLand", "preco"=>"60.700", "img"=>"pro_20", "categoria"=>"Aviador"],
            ["id"=>21, "nome"=>"TG - Aviador 39", "preco"=>"41.400", "img"=>"pro_21", "categoria"=>"Aviador"],
            ["id"=>22, "nome"=>"Aviador - Royal Maces", "preco"=>"71.400", "img"=>"pro_22", "categoria"=>"Aviador"],
            ["id"=>23, "nome"=>"TG - Perpetuo", "preco"=>"165.00", "img"=>"pro_23", "categoria"=>"Aviador"],
            ["id"=>24, "nome"=>"TG - Ceratanium", "preco"=>"98.700", "img"=>"pro_24", "categoria"=>"Aviador"],

            ["id"=>25, "nome"=>"Portofino 37", "preco"=>"36.600", "img"=>"pro_25", "categoria"=>"Vintage"],
            ["id"=>26, "nome"=>"Portofino 39", "preco"=>"34.600", "img"=>"pro_26", "categoria"=>"Vintage"],
            ["id"=>27, "nome"=>"Portofino Manual", "preco"=>"57.800", "img"=>"pro_27", "categoria"=>"Vintage"],
            ["id"=>28, "nome"=>"Portofino 37 - LSG", "preco"=>"38.00", "img"=>"pro_28", "categoria"=>"Vintage"],
            ["id"=>29, "nome"=>"Portofino 37", "preco"=>"32.600", "img"=>"pro_29", "categoria"=>"Vintage"],
            ["id"=>30, "nome"=>"Portofino Automatico", "preco"=>"74.800", "img"=>"pro_30", "categoria"=>"Vintage"]
    ];
?>